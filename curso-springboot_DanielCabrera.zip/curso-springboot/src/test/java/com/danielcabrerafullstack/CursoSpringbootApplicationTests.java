package com.danielcabrerafullstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CursoSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
